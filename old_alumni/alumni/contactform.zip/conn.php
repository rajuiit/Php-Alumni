<?php
	$con=mysqli_connect('localhost:3306','proconfl_mahedy','mahedy01798173317');

	mysqli_select_db($con,'proconfl_csepc_db');

?>