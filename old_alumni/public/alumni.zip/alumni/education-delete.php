<?php
	include 'conn.php';

	$id=$_GET['id'];

	$q="DELETE FROM `education_info` WHERE id='$id'";

	mysqli_query($con,$q);

	header('location:admin-alumnus.php');

?>